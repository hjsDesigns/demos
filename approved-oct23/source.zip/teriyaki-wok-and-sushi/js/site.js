/* ============================================================
   WEBSITE FACTORY — site.js
   Nav toggle · live open/closed clock (Pacific time) · scroll-reveal ·
   count-up numbers · contact form success.
   The ONLY thing to edit per client is the HOURS block right below.
   ============================================================ */

/* ------------------------------------------------------------
   HOURS CONFIG  — fill from the client's Google listing.
   Days are 0=Sunday … 6=Saturday. Each day is [open, close] in
   decimal 24h hours (6.5 = 6:30 am, 18 = 6:00 pm, 23.5 = 11:30 pm).
   null = closed that day. Closing past midnight: use 26 for 2 am.
   ------------------------------------------------------------ */
/* Teriyaki Wok & Sushi, Bonney Lake.
   Sun / Tue–Fri / Sat from their own site (teriyakiwoksushiwa.com, "BUSINESS
   HOURS"). Monday is omitted there; Restaurantji's listing for the same
   address + phone says Monday closed, so that's what ships. */
var HOURS = {
  tz: 'America/Los_Angeles',          // Pacific, wherever the viewer is
  days: {
    0: [12, 20.5],                    // Sunday      12:00 pm – 8:30 pm
    1: null,                          // Monday      closed
    2: [11, 20.5],                    // Tuesday     11:00 am – 8:30 pm
    3: [11, 20.5],                    // Wednesday   11:00 am – 8:30 pm
    4: [11, 20.5],                    // Thursday    11:00 am – 8:30 pm
    5: [11, 20.5],                    // Friday      11:00 am – 8:30 pm
    6: [12, 20.5]                     // Saturday    12:00 pm – 8:30 pm
  }
};

/* ------------------------------------------------------------
   CUSTOM CLOSE RULES HOOK  (optional — leave as-is for most clients)
   Two functions site.js calls every minute. `p` is the Pacific "now":
   {day, h, y, mo, d}  (day 0-6, h decimal hour, y year, mo month 0-11, d date)

   customClosure(p) → return a string to mark the whole day CLOSED
                      ("Closed today for Labor Day"), or null.
   customClose(p, close) → return an adjusted closing hour for today.

   Reference-build example (path in README, "HOURS config"): Friday closed
   at the earlier of 6 pm or SUNDOWN (NOAA sunset math), and US holidays
   from their rate sheet returned a closure string. Port that logic here
   only when the business actually has such a rule.
   ------------------------------------------------------------ */
function customClosure(p){ return null; }
function customClose(p, close){ return close; }


(function(){
  'use strict';
  document.documentElement.classList.add('js');
  var $=function(s,r){return (r||document).querySelector(s)};
  var $$=function(s,r){return Array.prototype.slice.call((r||document).querySelectorAll(s))};

  /* ---------- mobile nav (toggle · Escape · outside-click · close on link) ---------- */
  var toggle=$('.nav-toggle'), nav=$('#main-nav');
  function setNav(open){nav.classList.toggle('open',open);toggle.setAttribute('aria-expanded',open?'true':'false');toggle.textContent=open?'✕':'☰'}
  if(toggle&&nav){
    toggle.addEventListener('click',function(e){e.stopPropagation();setNav(!nav.classList.contains('open'))});
    $$('#main-nav a').forEach(function(a){a.addEventListener('click',function(){setNav(false)})});
    document.addEventListener('click',function(e){if(nav.classList.contains('open')&&!nav.contains(e.target)&&e.target!==toggle)setNav(false)});
    document.addEventListener('keydown',function(e){if(e.key==='Escape'&&nav.classList.contains('open')){setNav(false);toggle.focus()}});
  }
  var y=$('#year'); if(y) y.textContent=new Date().getFullYear();

  /* ---------- Pacific time, wherever the viewer is ---------- */
  // Pitch/demo switch: ?demo=15.75 (hour, Pacific) [&day=1-6] [&date=YYYY-MM-DD]
  // freezes the clock so "Open now" can be shown after hours. No UI exposes it.
  var DEMO=(function(){try{var q=new URLSearchParams(location.search);if(!q.has('demo'))return null;
    var h=parseFloat(q.get('demo'));var d=parseInt(q.get('day')||'3',10);if(isNaN(h))return null;var o={day:d,h:h};
    var ds=q.get('date');if(ds&&/^\d{4}-\d{2}-\d{2}$/.test(ds)){var dt=new Date(ds+'T12:00:00');o.y=dt.getFullYear();o.mo=dt.getMonth();o.d=dt.getDate();o.day=dt.getDay()}
    return o}catch(e){return null}})();
  function pacificNow(){
    if(DEMO) return DEMO;
    var parts=new Intl.DateTimeFormat('en-US',{timeZone:HOURS.tz,weekday:'short',year:'numeric',month:'numeric',day:'numeric',hour:'numeric',minute:'numeric',hour12:false}).formatToParts(new Date());
    var o={};parts.forEach(function(p){o[p.type]=p.value});
    var days={Sun:0,Mon:1,Tue:2,Wed:3,Thu:4,Fri:5,Sat:6};
    var h=parseInt(o.hour,10)%24, m=parseInt(o.minute,10);
    return {day:days[o.weekday], h:h+m/60, y:parseInt(o.year,10), mo:parseInt(o.month,10)-1, d:parseInt(o.day,10)};
  }
  function fmt(h){h=h%24;var ap=h>=12?'pm':'am';var hh=Math.floor(h)%12;if(hh===0)hh=12;var mm=Math.round((h%1)*60);if(mm===60){mm=0;hh=(hh%12)+1}return hh+(mm?':'+(mm<10?'0':'')+mm:'')+' '+ap}
  function dayName(d){return ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'][d]}
  function hoursFor(day){return HOURS.days[day]||null}

  function computeStatus(){
    var p=pacificNow(), d=p.day, h=p.h;
    var closure=customClosure(p);
    if(closure) return {open:false,text:'Closed today for '+closure};
    // still inside yesterday's after-midnight hours? (e.g. a bar closing at 2 am = 26)
    var yd=(d+6)%7, yh=hoursFor(yd);
    if(yh&&yh[1]>24&&h<yh[1]-24) return {open:true,text:'Open now · til '+fmt(yh[1])};
    var today=hoursFor(d);
    if(today){
      var close=customClose(p,today[1]);
      if(h>=today[0]&&h<close) return {open:true,text:'Open now · til '+fmt(close),soon:(close-h)<=1};
      if(h<today[0]) return {open:false,text:'Opens today at '+fmt(today[0])};
    }
    // find the next open day
    for(var i=1;i<=7;i++){
      var nd=(d+i)%7, nh=hoursFor(nd);
      if(nh){var label=i===1?'tomorrow':dayName(nd);return {open:false,text:'Closed · opens '+label+' at '+fmt(nh[0])}}
    }
    return {open:false,text:'Closed'};
  }
  function applyStatus(){
    var s=computeStatus(), p=pacificNow();
    var hp=$('#hdrLive'), ht=$('#hdrLiveText');
    if(hp&&ht){hp.className='hdr-live '+(s.open?'is-open':'is-closed');ht.innerHTML=(s.open?'Open':'Closed')+' <span class="txt-long">· '+s.text.replace(/^Open now · /,'').replace(/^Closed · /,'')+'</span>';}
    var sl=$('#statusLine'), st=$('#statusText');
    if(sl&&st){sl.className='live-line '+(s.open?'is-open':'is-closed');st.textContent=s.text;}
    $$('#hoursList li[data-days]').forEach(function(li){li.classList.toggle('today',li.getAttribute('data-days').split(',').indexOf(String(p.day))>-1)});
  }
  applyStatus(); setInterval(applyStatus,60000);
  window.__site={pacificNow:pacificNow,computeStatus:computeStatus,HOURS:HOURS}; // handy in the console

  /* ---------- scroll-reveal + count-up ---------- */
  var io=typeof IntersectionObserver==='function'?new IntersectionObserver(function(entries){
    entries.forEach(function(en){
      if(!en.isIntersecting)return;
      en.target.classList.add('in');
      $$('.count',en.target).forEach(function(c){
        if(c.dataset.done)return; c.dataset.done='1';
        var to=parseInt(c.getAttribute('data-to'),10), from=parseInt(c.getAttribute('data-from')||'0',10), t0=null;
        var reduce=window.matchMedia('(prefers-reduced-motion:reduce)').matches;
        if(reduce){c.textContent=to;return}
        function step(ts){if(!t0)t0=ts;var k=Math.min(1,(ts-t0)/1400);var e=1-Math.pow(1-k,3);c.textContent=Math.round(from+(to-from)*e);if(k<1)requestAnimationFrame(step)}
        requestAnimationFrame(step);
      });
      io.unobserve(en.target);
    });
  },{threshold:.06,rootMargin:'0px 0px -6% 0px'}):null;
  $$('.reveal').forEach(function(el){if(io)io.observe(el);else el.classList.add('in')});

  /* Contact uses verified phone/ordering links until an owner inbox is configured. */

  /* ---------- MENU TITLE CARDS ----------
     Each category headline is itself the tap target and rolls the real items
     out in place (TITLE CARDS UNROLL). The affordance is a downward chevron
     that flips up (ARROW LAW) — never a plus sign. */
  $$('.card-roll').forEach(function(card,index){
    var head=$('.roll-head',card), body=$('.roll-body',card);
    if(!head||!body)return;
    body.id='menu-category-'+index; head.setAttribute('aria-controls',body.id); body.hidden=true;
    head.addEventListener('click',function(){
      var open=card.classList.toggle('is-open');
      head.setAttribute('aria-expanded',open?'true':'false');
      body.hidden=!open;
    });
  });

  /* ---------- SIGNATURE GADGET — BUILD YOUR BENTO ----------
     Five real bentos off their own ordering page (B-3 … B-7). Every box
     carries the same four sides, so the only choice is the main: tap a pill,
     the photo and the price change. No numbers to type, no modes, no legend.
     `note` is set only where the photo shows the main plated rather than
     boxed — so nothing on screen claims to be a picture it isn't. */
  var BENTO={
    chicken : {name:'B-3 Chicken Teriyaki Bento', price:'$19.95', note:''},
    beef    : {name:'B-4 Beef Teriyaki Bento',    price:'$20.95', note:'Photo shows their beef teriyaki, the main in this box.'},
    pork    : {name:'B-5 Pork Teriyaki Bento',    price:'$19.95', note:'Photo shows their pork teriyaki, the main in this box.'},
    salmon  : {name:'B-6 Salmon Teri Bento',      price:'$20.95', note:''},
    shortrib: {name:'B-7 Short Rib Bento',        price:'$28.95', note:'Photo shows their beef short ribs, the main in this box.'}
  };
  var picks=$$('.bento-picks .pick'), shots=$$('.bento-shot .bshot'),
      bName=$('#bentoName'), bPrice=$('#bentoPrice'), bNote=$('#bentoNote');
  if(picks.length && bName && bPrice){
    var setBento=function(k){
      var d=BENTO[k]; if(!d)return;
      picks.forEach(function(b){var on=b.getAttribute('data-k')===k;
        b.classList.toggle('is-on',on); b.setAttribute('aria-pressed',on?'true':'false')});
      shots.forEach(function(im){var active=im.getAttribute('data-k')===k;im.classList.toggle('on',active);im.setAttribute('aria-hidden',active?'false':'true')});
      bName.textContent=d.name; bPrice.textContent=d.price;
      if(d.note){bNote.textContent=d.note;bNote.hidden=false}else{bNote.textContent='';bNote.hidden=true}
    };
    picks.forEach(function(b){b.addEventListener('click',function(){setBento(b.getAttribute('data-k'))})});
    setBento('chicken');
  }

  /* Search existing dishes without replacing the browsable category cards. */
  var search=$('#menuSearch'), clearSearch=$('#clearMenuSearch'), searchStatus=$('#menuSearchStatus'), bentoLink=$('#bentoSearchLink');
  if(search){
    $('.menu-search').hidden=false;
    function filterMenu(){
      var query=search.value.trim().toLocaleLowerCase(), count=0;
      $$('.card-roll').forEach(function(card){
        var matches=0, head=$('.roll-head',card), body=$('.roll-body',card);
        $$('.menu-list li',card).forEach(function(row){
          var match=!query||row.textContent.toLocaleLowerCase().indexOf(query)!==-1;
          row.hidden=!match;if(match)matches++;
        });
        card.hidden=!!query&&!matches;count+=matches;
        var open=!!query&&!!matches;card.classList.toggle('is-open',open);
        head.setAttribute('aria-expanded',open?'true':'false');body.hidden=!open;
      });
      var bentos=query?Object.keys(BENTO).filter(function(k){return BENTO[k].name.toLocaleLowerCase().indexOf(query)!==-1}):[];
      bentoLink.hidden=!bentos.length;bentoLink.setAttribute('data-match',bentos[0]||'');clearSearch.hidden=!query;
      searchStatus.textContent=!query?'':count+' menu '+(count===1?'match':'matches')+(bentos.length?' + '+bentos.length+' bento '+(bentos.length===1?'box':'boxes'):'')+(count||bentos.length?'':' — try another dish.');
    }
    bentoLink.addEventListener('click',function(){var match=bentoLink.getAttribute('data-match');if(match)setBento(match)});
    search.addEventListener('input',filterMenu);
    clearSearch.addEventListener('click',function(){search.value='';filterMenu();search.focus()});
  }
})();
