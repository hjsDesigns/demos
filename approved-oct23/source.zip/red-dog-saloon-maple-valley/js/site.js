/* ============================================================
   THE RED DOG SALOON — site.js
   Nav toggle · live open/closed clock (Pacific) · scroll-reveal ·
   count-up · contact form · title-cards-unroll · THE CHILI-DOG BOARD
   ============================================================ */

/* ------------------------------------------------------------
   HOURS — the one internally consistent seven-day set that could be
   sourced: the Restaurantji listing for this exact address, page
   footer "Updated on: Aug 17, 2026".
     Mon–Thu 12 PM – 12 AM · Fri–Sat 12 PM – 2 AM · Sun 12 PM – 11 PM
   PROVISIONAL — one conflict flagged in HANDOFF-CODEX.md: another
   listing shows Sunday running to 2 AM rather than 11 PM. Confirm the
   Sunday close with the bar before this goes live.
   0 = Sunday … 6 = Saturday, decimal 24h. 24 = midnight, 26 = 2 AM the
   next morning — the clock knows the bar is still open after midnight.
   ------------------------------------------------------------ */
var HOURS = {
  tz: 'America/Los_Angeles',
  days: {
    0: [12, 23],                      // Sunday    12:00 PM – 11:00 PM
    1: [12, 24],                      // Monday    12:00 PM – 12:00 AM
    2: [12, 24],                      // Tuesday
    3: [12, 24],                      // Wednesday
    4: [12, 24],                      // Thursday
    5: [12, 26],                      // Friday    12:00 PM –  2:00 AM
    6: [12, 26]                       // Saturday  12:00 PM –  2:00 AM
  }
};

/* No holiday or seasonal rule is confirmed for this bar — leave as-is. */
function customClosure(p){ return null; }
function customClose(p, close){ return close; }


(function(){
  'use strict';
  document.documentElement.classList.add('js');
  var $=function(s,r){return (r||document).querySelector(s)};
  var $$=function(s,r){return Array.prototype.slice.call((r||document).querySelectorAll(s))};
  var REDUCE=function(){return window.matchMedia('(prefers-reduced-motion:reduce)').matches};

  /* ---------- mobile nav (toggle · Escape · outside-click · close on link) ---------- */
  var toggle=$('.nav-toggle'), nav=$('#main-nav');
  function setNav(open){nav.classList.toggle('open',open);toggle.setAttribute('aria-expanded',open?'true':'false');toggle.textContent=open?'✕':'☰'}
  if(toggle&&nav){
    toggle.addEventListener('click',function(e){e.stopPropagation();setNav(!nav.classList.contains('open'))});
    $$('#main-nav a').forEach(function(a){a.addEventListener('click',function(){setNav(false)})});
    document.addEventListener('click',function(e){if(nav.classList.contains('open')&&!nav.contains(e.target)&&e.target!==toggle)setNav(false)});
    document.addEventListener('keydown',function(e){if(e.key==='Escape'&&nav.classList.contains('open')){setNav(false);toggle.focus()}});
  }
  var y=$('#year'); if(y) y.textContent=new Date().getFullYear();

  /* ---------- Pacific time, wherever the viewer is ---------- */
  // Pitch/demo switch: ?demo=15.75 (hour, Pacific) [&day=0-6] [&date=YYYY-MM-DD]
  var DEMO=(function(){try{var q=new URLSearchParams(location.search);if(!q.has('demo'))return null;
    var h=parseFloat(q.get('demo'));var d=parseInt(q.get('day')||'3',10);if(isNaN(h))return null;var o={day:d,h:h};
    var ds=q.get('date');if(ds&&/^\d{4}-\d{2}-\d{2}$/.test(ds)){var dt=new Date(ds+'T12:00:00');o.y=dt.getFullYear();o.mo=dt.getMonth();o.d=dt.getDate();o.day=dt.getDay()}
    return o}catch(e){return null}})();
  function pacificNow(){
    if(DEMO) return DEMO;
    var parts=new Intl.DateTimeFormat('en-US',{timeZone:HOURS.tz,weekday:'short',year:'numeric',month:'numeric',day:'numeric',hour:'numeric',minute:'numeric',hour12:false}).formatToParts(new Date());
    var o={};parts.forEach(function(p){o[p.type]=p.value});
    var days={Sun:0,Mon:1,Tue:2,Wed:3,Thu:4,Fri:5,Sat:6};
    var h=parseInt(o.hour,10)%24, m=parseInt(o.minute,10);
    return {day:days[o.weekday], h:h+m/60, y:parseInt(o.year,10), mo:parseInt(o.month,10)-1, d:parseInt(o.day,10)};
  }
  function fmt(h){h=h%24;var ap=h>=12?'pm':'am';var hh=Math.floor(h)%12;if(hh===0)hh=12;var mm=Math.round((h%1)*60);if(mm===60){mm=0;hh=(hh%12)+1}return hh+(mm?':'+(mm<10?'0':'')+mm:'')+' '+ap}
  function dayName(d){return ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'][d]}
  function hoursFor(day){return HOURS.days[day]||null}

  function computeStatus(){
    // A conflicting Sunday close cannot support a reliable live status.
    return {open:null,confirmed:false,text:'Call to confirm today’s hours'};
  }
  function applyStatus(){
    var p=pacificNow();
    $$('#hoursList li[data-days]').forEach(function(li){li.classList.toggle('today',li.getAttribute('data-days').split(',').indexOf(String(p.day))>-1)});
  }
  applyStatus(); setInterval(applyStatus,60000);
  window.__site={pacificNow:pacificNow,computeStatus:computeStatus,HOURS:HOURS};

  /* ---------- scroll-reveal + count-up ---------- */
  var io=new IntersectionObserver(function(entries){
    entries.forEach(function(en){
      if(!en.isIntersecting)return;
      en.target.classList.add('in');
      $$('.count',en.target).forEach(function(c){
        if(c.dataset.done)return; c.dataset.done='1';
        var to=parseInt(c.getAttribute('data-to'),10), from=parseInt(c.getAttribute('data-from')||'0',10), t0=null;
        var show=function(n){c.textContent=n.toLocaleString('en-US')};
        if(REDUCE()){show(to);return}
        function step(ts){if(!t0)t0=ts;var k=Math.min(1,(ts-t0)/1400);var e=1-Math.pow(1-k,3);show(Math.round(from+(to-from)*e));if(k<1)requestAnimationFrame(step)}
        requestAnimationFrame(step);
      });
      io.unobserve(en.target);
    });
  },{threshold:.06,rootMargin:'0px 0px -6% 0px'});
  $$('.reveal').forEach(function(el){io.observe(el)});

  /* ---------- contact form ----------
     Demo mode (hidden access_key empty): explicitly say no message was sent.
     Live mode (key filled at go-live by pages-golive.sh): POST to Web3Forms
     from the visitor's browser -> lands in the owner's inbox. */
  var form=$('.contact-form'), ok=$('.form-success');
  if(form&&ok){form.addEventListener('submit',function(e){
    e.preventDefault();
    var btn=form.querySelector('button[type=submit]'), keyEl=form.querySelector('[name=access_key]'), key=keyEl?keyEl.value.trim():'';
    function done(){ok.classList.add('show');ok.setAttribute('role','status');btn.disabled=true}
    if(!key){ok.textContent='Message not sent. Please use the phone link to contact the business.';ok.classList.add('show');ok.setAttribute('role','status');return}
    var label=btn.textContent; btn.disabled=true; btn.textContent='Sending…';
    var data={}; new FormData(form).forEach(function(v,k){data[k]=v});
    data.subject=data.subject||('New message from your website ('+document.title+')');
    fetch('https://api.web3forms.com/submit',{method:'POST',headers:{'Content-Type':'application/json','Accept':'application/json'},body:JSON.stringify(data)})
      .then(function(r){return r.json()}).then(function(j){if(j&&j.success){done()}else{throw new Error('send failed')}})
      .catch(function(){btn.disabled=false;btn.textContent=label;ok.textContent='Couldn’t send just now — call the bar instead.';ok.classList.add('show');ok.setAttribute('role','alert')});
  })}

  /* ---------- TITLE CARDS UNROLL — the headline is the tap target ---------- */
  $$('.unroll').forEach(function(btn){
    var panel=document.getElementById(btn.getAttribute('aria-controls'));
    if(!panel) return;
    btn.addEventListener('click',function(){
      var open=btn.getAttribute('aria-expanded')==='true';
      btn.setAttribute('aria-expanded',open?'false':'true');
      panel.setAttribute('data-open',open?'0':'1');
    });
  });

  /* ---------- SIGNATURE GADGET — THE CHILI-DOG BOARD -------------------
     One tap on a labelled name builds that dog on the bun; tapping the same
     name again clears the plate. Every name, price and description below is
     read straight off the chili-dog board photographed on their own wall —
     nothing here is invented and nothing here repeats the main menu.
     Deterministic: pure state swap, no timers, no random. */
  (function(){
    var stage=$('#dogStage'), pills=$('#dogPills');
    if(!stage||!pills) return;
    var nameEl=$('#dogName'), priceEl=$('#dogPrice'), descEl=$('#dogDesc');
    var REST={name:nameEl.textContent, price:priceEl.textContent, desc:descEl.childNodes[0].nodeValue};
    var CITE=descEl.querySelector('cite');
    var current=null;

    function paint(btn){
      $$('button',pills).forEach(function(b){b.setAttribute('aria-pressed', b===btn ? 'true':'false')});
      if(!btn){
        stage.removeAttribute('data-dog');
        nameEl.textContent=REST.name; priceEl.textContent=REST.price;
        descEl.childNodes[0].nodeValue=REST.desc;
        CITE.textContent='Photographed from the board in their room';
        current=null; return;
      }
      stage.setAttribute('data-dog', btn.getAttribute('data-dog'));
      nameEl.textContent=btn.getAttribute('data-name');
      priceEl.textContent=btn.getAttribute('data-price');
      descEl.childNodes[0].nodeValue=btn.getAttribute('data-desc')+' ';
      CITE.textContent='The board’s own words';
      current=btn;
    }

    $$('button',pills).forEach(function(b){
      b.addEventListener('click',function(){ paint(current===b ? null : b) });
    });
  })();

})();
