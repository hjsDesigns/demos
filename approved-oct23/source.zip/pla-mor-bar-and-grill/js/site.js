/* ============================================================
   PLA-MOR BAR & GRILL — site.js
   Nav toggle · live open/closed clock (Pacific) · scroll-reveal ·
   contact form · title-cards-unroll · THE SPECIALS SHEET
   ============================================================ */

/* ------------------------------------------------------------
   HOURS — Restaurantji's structured listing for this place
   ("Mo 11:00-24:00 … Fr 11:00-2:00 … Su 11:00-22:00"), which Apple
   Maps and Waze both match. 0 = Sunday … 6 = Saturday. Decimal 24h.
   26 = 2 AM the next morning, 24 = midnight — the clock knows the bar
   is still open after midnight on a Friday and Saturday night.
   ------------------------------------------------------------ */
var HOURS = {
  tz: 'America/Los_Angeles',
  days: {
    0: [11, 22],                      // Sunday    11:00 AM – 10:00 PM
    1: [11, 24],                      // Monday    11:00 AM – 12:00 AM
    2: [11, 24],                      // Tuesday
    3: [11, 24],                      // Wednesday
    4: [11, 24],                      // Thursday
    5: [11, 26],                      // Friday    11:00 AM –  2:00 AM
    6: [11, 26]                       // Saturday  11:00 AM –  2:00 AM
  }
};

/* No holiday or seasonal rule is confirmed for this bar — leave as-is. */
function customClosure(p){ return null; }
function customClose(p, close){ return close; }

/* ------------------------------------------------------------
   THE SPECIALS SHEET — transcribed word for word from a photograph
   of the "Daily Specials" page in their menu binder. Dish and wording
   only: the prices printed on that sheet belong to an older menu than
   the one on the tables now, so no price is shown here.
   ------------------------------------------------------------ */
var SPECIALS = {
  1: {day:'Monday',    dish:'Prime Rib Dinner', desc:'14 oz., baked potato or fries, and salad.',            extra:''},
  2: {day:'Tuesday',   dish:'Burger Night',     desc:'Every regular-priced burger on the menu, a dollar off.', extra:''},
  3: {day:'Wednesday', dish:'Steak Dinner',     desc:'14 oz. rib eye steak, baked potato or fries, and salad.', extra:''},
  4: {day:'Thursday',  dish:'BBQ Rib Dinner',   desc:'Baked potato or salad.',                                extra:'Double order of ribs also on the sheet'},
  5: {day:'Friday',    dish:'Fish & Chips',     desc:'Hand battered cod, fries or salad.',                    extra:'Double order of fish · steak dinner also on the sheet'}
};
var WEEKEND = {day:'The photographed sheet', dish:'Explore the weeknight dishes', desc:'Choose a day above. Call the bar to confirm today’s dishes and prices.', extra:''};


(function(){
  'use strict';
  document.documentElement.classList.add('js');
  var $=function(s,r){return (r||document).querySelector(s)};
  var $$=function(s,r){return Array.prototype.slice.call((r||document).querySelectorAll(s))};
  var REDUCE=function(){return window.matchMedia('(prefers-reduced-motion:reduce)').matches};

  /* ---------- mobile nav ---------- */
  var toggle=$('.nav-toggle'), nav=$('#main-nav');
  function setNav(open){nav.classList.toggle('open',open);toggle.setAttribute('aria-expanded',open?'true':'false');toggle.textContent=open?'✕':'☰'}
  if(toggle&&nav){
    toggle.addEventListener('click',function(e){e.stopPropagation();setNav(!nav.classList.contains('open'))});
    $$('#main-nav a').forEach(function(a){a.addEventListener('click',function(){setNav(false)})});
    document.addEventListener('click',function(e){if(nav.classList.contains('open')&&!nav.contains(e.target)&&e.target!==toggle)setNav(false)});
    document.addEventListener('keydown',function(e){if(e.key==='Escape'&&nav.classList.contains('open')){setNav(false);toggle.focus()}});
  }
  var y=$('#year'); if(y) y.textContent=new Date().getFullYear();

  /* ---------- Pacific time, wherever the viewer is ---------- */
  var DEMO=(function(){try{var q=new URLSearchParams(location.search);if(!q.has('demo'))return null;
    var h=parseFloat(q.get('demo'));var d=parseInt(q.get('day')||'3',10);if(isNaN(h))return null;var o={day:d,h:h};
    var ds=q.get('date');if(ds&&/^\d{4}-\d{2}-\d{2}$/.test(ds)){var dt=new Date(ds+'T12:00:00');o.y=dt.getFullYear();o.mo=dt.getMonth();o.d=dt.getDate();o.day=dt.getDay()}
    return o}catch(e){return null}})();
  function pacificNow(){
    if(DEMO) return DEMO;
    var parts=new Intl.DateTimeFormat('en-US',{timeZone:HOURS.tz,weekday:'short',year:'numeric',month:'numeric',day:'numeric',hour:'numeric',minute:'numeric',hour12:false}).formatToParts(new Date());
    var o={};parts.forEach(function(p){o[p.type]=p.value});
    var days={Sun:0,Mon:1,Tue:2,Wed:3,Thu:4,Fri:5,Sat:6};
    var h=parseInt(o.hour,10)%24, m=parseInt(o.minute,10);
    return {day:days[o.weekday], h:h+m/60, y:parseInt(o.year,10), mo:parseInt(o.month,10)-1, d:parseInt(o.day,10)};
  }
  function fmt(h){h=h%24;var ap=h>=12?'pm':'am';var hh=Math.floor(h)%12;if(hh===0)hh=12;var mm=Math.round((h%1)*60);if(mm===60){mm=0;hh=(hh%12)+1}return hh+(mm?':'+(mm<10?'0':'')+mm:'')+' '+ap}
  function dayName(d){return ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'][d]}
  function hoursFor(day){return HOURS.days[day]||null}

  function computeStatus(){
    var p=pacificNow(), d=p.day, h=p.h;
    var closure=customClosure(p);
    if(closure) return {open:false,text:'Closed today for '+closure};
    var yd=(d+6)%7, yh=hoursFor(yd);
    if(yh&&yh[1]>24&&h<yh[1]-24) return {open:true,text:'Open now · til '+fmt(yh[1])};
    var today=hoursFor(d);
    if(today){
      var close=customClose(p,today[1]);
      if(h>=today[0]&&h<close) return {open:true,text:'Open now · til '+fmt(close),soon:(close-h)<=1};
      if(h<today[0]) return {open:false,text:'Opens today at '+fmt(today[0])};
    }
    for(var i=1;i<=7;i++){
      var nd=(d+i)%7, nh=hoursFor(nd);
      if(nh){var label=i===1?'tomorrow':dayName(nd);return {open:false,text:'Closed · opens '+label+' at '+fmt(nh[0])}}
    }
    return {open:false,text:'Closed'};
  }
  function applyStatus(){
    var s=computeStatus(), p=pacificNow();
    var hp=$('#hdrLive'), ht=$('#hdrLiveText');
    if(hp&&ht){hp.className='hdr-live '+(s.open?'is-open':'is-closed');ht.innerHTML=(s.open?'Open':'Closed')+' <span class="txt-long">· '+s.text.replace(/^Open now · /,'').replace(/^Closed · /,'')+'</span>';}
    var sl=$('#statusLine'), st=$('#statusText');
    if(sl&&st){sl.className='live-line '+(s.open?'is-open':'is-closed');st.textContent=s.text;}
    $$('#hoursList li[data-days]').forEach(function(li){li.classList.toggle('today',li.getAttribute('data-days').split(',').indexOf(String(p.day))>-1)});
  }
  applyStatus(); setInterval(applyStatus,60000);
  window.__site={pacificNow:pacificNow,computeStatus:computeStatus,HOURS:HOURS};

  /* ---------- scroll-reveal ---------- */
  var io=new IntersectionObserver(function(entries){
    entries.forEach(function(en){
      if(!en.isIntersecting)return;
      en.target.classList.add('in');
      io.unobserve(en.target);
    });
  },{threshold:.06,rootMargin:'0px 0px -6% 0px'});
  $$('.reveal').forEach(function(el){io.observe(el)});

  /* ---------- contact form ---------- */
  var form=$('.contact-form'), ok=$('.form-success');
  if(form&&ok){form.addEventListener('submit',function(e){e.preventDefault();ok.classList.add('show');ok.setAttribute('role','status');form.querySelector('button[type=submit]').disabled=true})}

  /* ---------- TITLE CARDS UNROLL — the headline is the tap target ---------- */
  $$('.unroll').forEach(function(btn){
    var panel=document.getElementById(btn.getAttribute('aria-controls'));
    if(!panel) return;
    btn.addEventListener('click',function(){
      var open=btn.getAttribute('aria-expanded')==='true';
      btn.setAttribute('aria-expanded',open?'false':'true');
      panel.setAttribute('data-open',open?'0':'1');
    });
  });

  /* ---------- SIGNATURE — THE SPECIALS SHEET ------------------------
     One tap on a night, the sheet swaps to that night's special. On
     load it lands on today; on a weekend it lands on the weekend line
     with no night selected, because the printed sheet has none. */
  var board=$('#board');
  if(board){
    var chips=$$('.day-chip'),
        elTag=$('#boardTag'), elDay=$('#boardDay'), elDish=$('#boardDish'),
        elDesc=$('#boardDesc'), elExtra=$('#boardExtra');

    function paint(rec, isToday, animate){
      elDay.textContent=rec.day;
      elDish.textContent=rec.dish;
      elDesc.textContent=rec.desc;
      elExtra.textContent=rec.extra||'';
      elTag.hidden=true;
      if(animate && !REDUCE()){
        board.classList.remove('swap');
        void board.offsetWidth;                 // reflow, so a rapid re-tap replays
        board.classList.add('swap');
      }
    }

    function select(n, animate){
      var today=pacificNow().day;
      chips.forEach(function(c){c.setAttribute('aria-pressed', String(parseInt(c.getAttribute('data-day'),10)===n))});
      if(SPECIALS[n]) paint(SPECIALS[n], false, animate);
      else paint(WEEKEND, false, animate);
    }

    chips.forEach(function(c){
      c.addEventListener('click',function(){select(parseInt(c.getAttribute('data-day'),10), true)});
    });

    var d=pacificNow().day;
    select(0, false);          // 0 falls through to the weekend line
  }

})();
